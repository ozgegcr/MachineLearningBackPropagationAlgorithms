x = load('Dataset4.txt');

 p111 = x(:,1:4);
%   p1 = x(:,1);
%    p2 = x(:,2);
%     p3 = x(:,3);
%      p4 = x(:,4);
%  
t = x(:, 5);

n1 = 0;
b = 0.3;

eta = 1.0; %Öğrenme Faktörü
emin = 0.001; % minimun eror
N = length(t); % giriş veri sayısı , 
        
n = 3; q = 30; p = 1; % NN yapısı q= gizli katmandaki norön sayısı bunu değiştircez 
                       % p = çıkış sayısı 1 ama arttırabiliriz
                       % q = 30 ya da 40 en iyi eğitimlerin elde edildiği
                       % nöron sayısı
Wih = rand(n+1,q); % Input-hidden weight matrix , yani girişten hidden layera bağlanan weightler  random verdik
Who = rand(q+1,p) ; 
DeltaWih = zeros(n+1,q); % Weight change matrices:ih , 0 lardan oluşan matris aşağıda kullanıyoruz
DeltaWho = zeros(q+1,p); %h-->output ,  0 lardan oluşan matris aşağıda kullanıyoruz

              

outh = [1 zeros(1,q)]; % Hidden neuron çıkış
out = zeros(1,p); % Output neuron çıkış
Sy=zeros(N,1); % Sistem çıkışı , 100x1 lik matris sıfırlardan olusuyor , aşağıda kullanıyoruz
deltaO = zeros(1,p); % Deta Error, çıkışta
deltaH = zeros(1,q+1); % Delta Error, hidden layer
sumerror = 2*emin; % While giriş şartı sağlansın
%while (sumerror > emin) % Iterate 
%sumerror = 0;
M = 2000;
for m = 1 : M %iterasyon
for k = 1:N % tüm forları içine alıyor
n1 = 1+ mod(n1,N);
neth = p111(k,:) * Wih + b; % Hidden activations , burda 1x4 matrix ile 4x30 matrisi carpıyoruz + b
                      
a = hardlim(neth);

outh = [1 1./(1 + exp(-neth))]; % Hidden signals
neto = outh * Who; % Output activations
out = 1./(1 + exp(-neto)); % Output signals
Ek = t(k) - out; % Error
Sy(k)=out; % Sistem çıkışı
deltaO = Ek .* out .* (1 - out); % Delta output

for h = 1:q+1 
DeltaWho(h,:) = deltaO * outh(h); % Delta W: hidden-output
end
for h = 2:q+1 % Delta hidden , 
deltaH(h) = (deltaO * Who(h,:)') * outh(h) * (1 - outh(h));
end
for i = 1:n+1 % Delta W: input-hidden
DeltaWih(i,:) = deltaH(2:q+1) * p111(k,i);
end

if a == t(n1)
    else
       if a>t(n1) 
         Wih = Wih - eta * DeltaWih;
         Who = Who - eta * DeltaWho;
         b = b-eta*(a-t(n1));
        else
        Wih = Wih + eta * DeltaWih;
        Who = Who + eta * DeltaWho;
        b = b-eta*(a-t(n1));
        end
end
%Wih = Wih + eta * DeltaWih;
%Who = Who + eta * DeltaWho;
sumerror = sumerror + sum(Ek.^2); % error değişimi
end
sumerror;
end

plot(t) % girdiğimiz istenilen çıkışların grafiği mavi olan 
hold
plot(Sy) % burasıda eğitim sonrası elde edilen çıkışların grafiği kırmızı olan