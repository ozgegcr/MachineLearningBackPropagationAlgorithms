eta = 1.0;%Öğrenme Faktörü
alpha=0.7;
emin = 0.001; % minimun eror
N = 4; % giriş veri sayısı
n = 2; q = 2; p = 1; % NN yapısı
Wih = rand(n+1,q); % Input-hidden weight matrix
Who = rand(q+1,p); % Hidden-output weight matrix
DeltaWih = zeros(n+1,q); % Weight change matrices:i-->h
DeltaWho = zeros(q+1,p); %h-->output
DeltaWihOld = zeros(n+1,q); %önceki adımdaki değişim
DeltaWhoOld = zeros(q+1,p);
Pi=rand(4,n+1); % girişler
T = [0.1000
0.9500
0.9500
0.1000]; % İstenilen çıkış
outh = [1 zeros(1,q)]; % Hidden neuron çıkış
out = zeros(1,p); % Output neuron çıkış
Sy=zeros(4,1);
deltaO = zeros(1,p); % Deta Error, çıkışta
deltaH = zeros(1,q+1); % Delta Error, hidden layer
sumerror = 2*emin;% While giriş şartı sağlansın
while (sumerror > emin) % Iterasyon
sumerror = 0;
for k = 1:N
neth = Pi(k,:) * Wih; % Hidden activations
outh = [1 1./(1 + exp(-neth))]; % Hidden signals
neto = outh * Who; % Output activations
out = 1./(1 + exp(-neto)); % Output signals
Ek = T(k) - out; % Error
Sy(k)=out; % Sistem çıkışı
deltaO = Ek .* out .* (1 - out); % Delta output
for h = 1:q+1
DeltaWho(h,:) = deltaO * outh(h); % Delta W: hidden-output
end
for h = 2:q+1 % Delta hidden
deltaH(h) = (deltaO * Who(h,:)') * outh(h) * (1 - outh(h));
end
for i = 1:n+1 % Delta W: input-hidden
DeltaWih(i,:) = deltaH(2:q+1) * Pi(k,i);
end
Wih = Wih + (1*alpha)*eta * DeltaWih + alpha * DeltaWihOld; %momentum
Who = Who + (1*alpha)*eta * DeltaWho + alpha * DeltaWhoOld;
DeltaWihOld = DeltaWih;
DeltaWhoOld = DeltaWho;
sumerror = sumerror + sum(Ek.^2); % error değişimi
end
sumerror;
end
plot(T)
hold
plot(Sy)